<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
</head>
<body>
    <div class="container mt-5">
    <!-- @if(session()->has('error'))
        <div class="alert alert-danger">
            {{ session()->get('error') }}
        </div>
    @endif
    @if(session()->has('success'))
        <div class="alert alert-danger">
            {{ session()->get('success') }}
        </div>
    @endif -->
        @if (Session::has('success'))
            <div class="flash_msg">
                <flash_messages :message_class="'success'" :time ='5' :message="'{{{ Session::get('success') }}}'" v-cloak></flash_messages>
            </div>
        @elseif (Session::has('error'))
            <div class="flash_msg">
                <flash_messages :message_class="'error'" :time ='5' :message="'{{{ Session::get('error') }}}'" v-cloak></flash_messages>
            </div>
        @endif
        <div class="container-fluid">
        <div class="dialog">
            <button class="btn btn-dark m-1" data-toggle="modal" data-target="#modal1">Add More Levels</button>
        </div>

        <div class="modal w-50 wallet-modal" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modallabel1" aria-hidden= "true">
                        <form class="bg-white" method="post" action="{{ route('wallet.store') }}">
                            <!-- CROSS Site Request Forgery Protection -->
                            @csrf
                            <div class="form-group m-5">
                                <label>Level</label>
                                <input type="text" class="form-control" name="level" id="level">
                            </div>
                            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block w-70">
                        </form>
        </div>

            @if(!empty($wallet))
                    <table class='table table-bordered'>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Level #</th>
                                <th>Value (eth)</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach ($wallet as $key => $wallet_data)
                            <tr>
                                <td>{{ $wallet_data->id }}</td>
                                <td>{{ $wallet_data->level }}</td>
                                <td>{{ $wallet_data->value }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="container mt-5">
                        <!-- Success message -->
                        <!-- @if(Session::has('success'))
                            <div class="alert alert-success">
                                {{Session::get('success')}}
                            </div>
                        @endif -->
                        <form action="" method="post" action="{{ route('wallet.find') }}">
                            <!-- CROSS Site Request Forgery Protection -->
                            @csrf
                            <div class="form-group">
                                <label>Level</label>
                                <input type="text" class="form-control" name="level" id="level">
                            </div>
                            <div class="form-group">
                                <label>Value</label>
                                <input type="text" class="form-control" name="value" id="value">
                            </div>
                            <input type="submit" name="send" value="Calculate" onclick="javascript:Find()" class="btn btn-dark btn-block">
                        </form>
                        <div class="container mt-5">
                            @if(!empty($wallet_sum))
                                <label><h6>Value:</h6></label><label>{{ $wallet_sum }}eth</label>
                            @endif
                        </div>
                    </div>
            @else
            @endif
        </div>
    </div>
</body>
<script>
//     $('#btn').click(function() {
//    $('#modelWindow').modal('show');
// });
</script>
</html>