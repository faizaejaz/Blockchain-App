<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="container mt-5">
    <!-- <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?> -->
        <?php if(Session::has('success')): ?>
            <div class="flash_msg">
                <flash_messages :message_class="'success'" :time ='5' :message="'<?php echo e(Session::get('success')); ?>'" v-cloak></flash_messages>
            </div>
        <?php elseif(Session::has('error')): ?>
            <div class="flash_msg">
                <flash_messages :message_class="'error'" :time ='5' :message="'<?php echo e(Session::get('error')); ?>'" v-cloak></flash_messages>
            </div>
        <?php endif; ?>
        <div class="container-fluid">
        <div class="dialog">
            <button class="btn btn-dark m-1" data-toggle="modal" data-target="#modal1">Add More Levels</button>
        </div>

        <div class="modal w-50 wallet-modal" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modallabel1" aria-hidden= "true">
                        <form class="bg-white" method="post" action="<?php echo e(route('wallet.store')); ?>">
                            <!-- CROSS Site Request Forgery Protection -->
                            <?php echo csrf_field(); ?>
                            <div class="form-group m-5">
                                <label>Level</label>
                                <input type="text" class="form-control" name="level" id="level">
                            </div>
                            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block w-70">
                        </form>
        </div>

            <?php if(!empty($wallet)): ?>
                    <table class='table table-bordered'>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Level #</th>
                                <th>Value (eth)</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($wallet_data->id); ?></td>
                                <td><?php echo e($wallet_data->level); ?></td>
                                <td><?php echo e($wallet_data->value); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="container mt-5">
                        <!-- Success message -->
                        <!-- <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?> -->
                        <form action="" method="post" action="<?php echo e(route('wallet.find')); ?>">
                            <!-- CROSS Site Request Forgery Protection -->
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Level</label>
                                <input type="text" class="form-control" name="level" id="level">
                            </div>
                            <div class="form-group">
                                <label>Value</label>
                                <input type="text" class="form-control" name="value" id="value">
                            </div>
                            <input type="submit" name="send" value="Calculate" onclick="javascript:Find()" class="btn btn-dark btn-block">
                        </form>
                        <div class="container mt-5">
                            <?php if(!empty($wallet_sum)): ?>
                                <label><h6>Value:</h6></label><label><?php echo e($wallet_sum); ?>eth</label>
                            <?php endif; ?>
                        </div>
                    </div>
            <?php else: ?>
            <?php endif; ?>
        </div>
    </div>
</body>
<script>
//     $('#btn').click(function() {
//    $('#modelWindow').modal('show');
// });
</script>
</html><?php /**PATH /Users/cv-pc/Desktop/BlockchainAssignment/blockchain-app/resources/views/wallet-list.blade.php ENDPATH**/ ?>