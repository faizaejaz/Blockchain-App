<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Redirect;
use App\Wallet;

class WalletController extends Controller
{
    public function wallet() {
        $wallet = Wallet::get();
        return view('wallet-list', compact('wallet'));
    }

    public function findparentwallet(Request $request) {
        // dd($request);
        $this->validate($request, [
            'level' => 'required',
            'value' => 'required'
         ]);
         $wallet_sum = null;
        $wallet_level = Wallet::select('level','value')->where('level', $request->input('level'))->first();
            if($wallet_level->level == $request->input('level') && $wallet_level->value == $request->input('value')){
                $wallet = Wallet::get();
                for($i=$request->input('level'); $i>0; $i--){
                    $wallet_level_value = Wallet::select('value')->where('level', $i)->first();
                    $wallet_sum = $wallet_sum + $wallet_level_value->value;
                }   
                // dd($wallet_sum);
                return view('wallet-list', compact('wallet_sum', 'wallet'));
            }
            else{
                return Redirect::back()->with('error', 'level does not exist!');
            }
       
    }

    public function wallet_store(Request $request) {
        // dd($request);
        $this->validate($request, [
            'level' => 'required'
         ]);
        
        $wallet_level = Wallet::where('level', $request->input('level'))->first();
            if($wallet_level){
                $wallet = Wallet::get();
                // return view('wallet-list', compact('wallet'))->with('error', 'This level already exists!');
                return Redirect::back()->with('error', 'This level already exists!');
            }
            else{
                $value = $request->input('level') - 1;
                $level_existence = Wallet::where('level', $value)->first();
                if($level_existence){
                    $parent_value = Wallet::select('value')->where('level', $value)->first(); 
                    $wallets = new Wallet;
                    $wallets->level = $request->input('level');
                    $wallets->value = $parent_value->value / 2;
                    $wallets->save();
                    $wallet = Wallet::get();
                    // return view('wallet-list', compact('wallet'))->with('success', 'Added Successfully!');
                    return Redirect::back()->with('success', 'Added Successfully!');
                }
                else{
                    return Redirect::back()->with('error', 'Does not have a previous parent!');
                    // return view('wallet-list', compact('wallet'))->with('error', 'Does not have a previous parent!');
                }
            }
       
    }

}
