<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class WalletSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('wallets')->insert([
        [
            'level' => '0',
            'value' => '10',
        ],
        [
            'level' => '1',
            'value' => '5',
        ],
        [
            'level' => '2',
            'value' => '2.5',
        ],
        [
            'level' => '3',
            'value' => '1.25',
        ],
        [
            'level' => '4',
            'value' => '0.625',
        ],
        [
            'level' => '5',
            'value' => '0.3125',
        ],
        [
            'level' => '6',
            'value' => '0.15625',
        ]
        ]);
    }
}
